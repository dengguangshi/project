-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 120.79.95.217
-- Port     : 3306
-- Database : sankei
-- 
-- Part : #1
-- Date : 2020-02-24 20:39:05
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `sankei_banner`
-- -----------------------------
DROP TABLE IF EXISTS `sankei_banner`;
CREATE TABLE `sankei_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `introduction` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL COMMENT '企业介绍',
  `history` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL COMMENT '发展历程',
  `culture` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL COMMENT '企业文化',
  `state` int(11) DEFAULT '0' COMMENT '1为选中',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci ROW_FORMAT=DYNAMIC COMMENT='Banner';

-- -----------------------------
-- Records of `sankei_banner`
-- -----------------------------
INSERT INTO `sankei_banner` VALUES ('1', 'http://pshangcheng.wsandos.com/SJ5e23fe83c2ed4.png', 'http://pshangcheng.wsandos.com/SJ5e23fedff2535.png', 'http://pshangcheng.wsandos.com/SJ5e393c28cb8b7.png', '1');
